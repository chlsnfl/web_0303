$(function(){
    $('.top li').hover(function(){
        $(this).find('.top-sub').fadeToggle();
    });

    setInterval(mySlide,3000);

    function mySlide(){
        $('.slide').animate({
            'left' : '-1200px'
        },500,function(){
            $('.slide img:first-child')
            .clone()
            .appendTo('.slide');
            $('.slide img:first-child').remove();
            $('.slide').css('left',0);
        });
    }

    $('.tab a').click(function(e){
        e.preventDefault();
        $('.tab a').removeclass('notice-active');
        $(this).addClass('notice-active');
        const myid=$(this).data("idx");
        $('.content>div').removeClass('notice-active');
        $("#"+myid).addClass('notice-active');
    })
});